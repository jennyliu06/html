alert("find a way to escape the room!")

//first room js
//selecting HTML elements
let door1 = document.getElementById("door1");
let chest1 = document.getElementById("chest1");
let chest2 = document.getElementById("chest2");
let chest3 = document.getElementById("chest3");
let hint = document.getElementById("hint");

//function that "opens" the first chest with the key
function openKeyChest(img){
  img.src = "chestwithkey.png";
  openKeyChest.called = true;
}

//function that changes the chests when hover
function openChest(img){
  img.src = "chest open.png";
}

//open door or key not found alert
function openDoor(img){
  if(openKeyChest.called){
    alert("door has been unlocked! congrats!");
    location.href = "room2.html";
  }
  else{
    alert("key has not been found yet");
  }
}

//hint button
function hintAlert1(){
  alert('try interacting with the chests to find the key that will unlock the door');
}
hint.onclick = hintAlert1;



