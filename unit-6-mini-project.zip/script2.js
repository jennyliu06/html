alert("find a way to escape the room!")
//second room js
//selecting html elements
let hint2 = document.getElementById("hint2");
let circle = document.getElementById("circle");
let square = document.getElementById("square");
let rectangle = document.getElementById("rectangle");
let answerInput = document.getElementById("answer");
let submitButton = document.getElementById("submit");

//hint button
function hintAlert2(){
  alert('try interacting with the shapes to find the password');
}
//circle 
function circleClick(){
  circle.style.backgroundColor = "red";
  circle.innerHTML = "color of this circle";
}
function mouseAway(){
  circle.innerHTML = " ";
  circle.style.backgroundColor = "cyan";
}
//square
function turnWhite(){
  square.style.color = "white";
  square.innerHTML = "color of this text";
}
function turnBlank(){
  square.innerHTML = " ";
}

//rectangle
function turnBlue(){
  rectangle.style.color = "blue";
  rectangle.innerHTML = "color of this text";
}
function turnBack(){
  rectangle.innerHTML = " ";
}

submitButton.addEventListener('click', function(){
  let userAnswer = answerInput.value;
  let correctAnswer = 'red white blue';

  if(userAnswer == correctAnswer){
    alert('your answer is correct! congrats on escaping!');
    location.href = "congrats.html"
  } else {
    alert('answer is incorrect, please try again');
  }
});

//events
hint2.onclick = hintAlert2;
circle.onclick = circleClick;
circle.onmouseout = mouseAway;
square.onmouseover = turnWhite;
square.onmouseout = turnBlank;
document.onkeydown = turnBlue;
document.onkeyup = turnBack;

